<?php
include("config/db.php");
include("includes/header.php");

$msg = "";

if (isset($_POST['register'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];

    $password = password_hash(
        $_POST['password'],
        PASSWORD_DEFAULT
    );

    $check = mysqli_query(
        $conn,
        "SELECT * FROM users WHERE email='$email'"
    );

    if (mysqli_num_rows($check) > 0) {
        $msg = "Email already exists!";
    } else {
        mysqli_query(
            $conn,
            "INSERT INTO users(name,email,password)
             VALUES('$name','$email','$password')"
        );

        $msg = "Registration Successful!";
    }
}
?>

<div class="container">

    <h2>User Registration</h2>

    <p class="message">
        <?php echo $msg; ?>
    </p>

    <form method="POST">

        <input type="text" name="name" placeholder="Enter Name" required>

        <input type="email" name="email" placeholder="Enter Email" required>

        <input type="password" name="password" placeholder="Enter Password" required>

        <button type="submit" name="register">
            Register
        </button>

    </form>

    <p class="login-link">
        <a href="login.php">Already Have Account?</a>
    </p>

</div>

<?php include("includes/footer.php"); ?>