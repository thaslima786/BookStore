<?php
session_start();
include("config/db.php");
include("includes/header.php");

$msg = "";

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $result = mysqli_query(
        $conn,
        "SELECT * FROM users WHERE email='$email'"
    );

    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['id'] = $user['id'];
        $_SESSION['name'] = $user['name'];

        header("Location: dashboard.php");
        exit();
    } else {
        $msg = "Invalid Email or Password";
    }
}
?>

<div class="container">

    <h2>User Login</h2>

    <p class="message">
        <?php echo $msg; ?>
    </p>

    <form method="POST">

        <input type="email" name="email" placeholder="Enter Email" required>

        <input type="password" name="password" placeholder="Enter Password" required>

        <button type="submit" name="login">
            Login
        </button>

    </form>

    <p class="login-link">
        <a href="register.php">Create Account</a>
    </p>

</div>

<?php include("includes/footer.php"); ?>