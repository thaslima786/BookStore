<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../login.php");
    exit();
}

include("../config/db.php");

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $sql = "DELETE FROM books WHERE id='$id'";

    if (mysqli_query($conn, $sql)) {
        header("Location: ../books.php");
        exit();
    } else {
        echo "Error deleting book!";
    }
} else {
    header("Location: ../books.php");
    exit();
}
?>