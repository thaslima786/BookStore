<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../login.php");
    exit();
}

include("../config/db.php");

if (!isset($_GET['id'])) {
    header("Location: ../books.php");
    exit();
}

$id = intval($_GET['id']);

$result = mysqli_query(
    $conn,
    "SELECT * FROM books WHERE id='$id'"
);

$book = mysqli_fetch_assoc($result);

if (!$book) {
    die("Book not found!");
}

if (isset($_POST['update_book'])) {
    $title = mysqli_real_escape_string(
        $conn,
        $_POST['title']
    );

    $author = mysqli_real_escape_string(
        $conn,
        $_POST['author']
    );

    $price = mysqli_real_escape_string(
        $conn,
        $_POST['price']
    );

    $sql = "UPDATE books
            SET title='$title',
                author='$author',
                price='$price'
            WHERE id='$id'";

    if (mysqli_query($conn, $sql)) {
        header("Location: ../books.php");
        exit();
    } else {
        echo "Error updating book!";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Edit Book</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f4f6f9;
        }

        .navbar {
            background: #2563eb;
            padding: 15px;
            text-align: center;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            margin: 0 20px;
            font-weight: bold;
        }

        .form-container {
            width: 500px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #2563eb;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-top: 15px;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 20px;
            background: #2563eb;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background: #1d4ed8;
        }

        .back-btn {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 15px;
            background: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>

</head>

<body>

    <div class="navbar">
        <a href="../dashboard.php">Dashboard</a>
        <a href="../books.php">Books</a>
        <a href="../logout.php">Logout</a>
    </div>

    <div class="form-container">

        <h2>✏ Edit Book</h2>

        <form method="POST">

            <label>Book Title</label>
            <input type="text" name="title" value="<?php echo $book['title']; ?>" required>

            <label>Author Name</label>
            <input type="text" name="author" value="<?php echo $book['author']; ?>" required>

            <label>Price</label>
            <input type="number" step="0.01" name="price" value="<?php echo $book['price']; ?>" required>

            <button type="submit" name="update_book">
                Update Book
            </button>

        </form>

        <a href="../books.php" class="back-btn">
            ← Back to Books
        </a>

    </div>

</body>

</html>