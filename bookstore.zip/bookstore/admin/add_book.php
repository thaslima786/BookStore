<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../login.php");
    exit();
}

include("../config/db.php");

$message = "";

if (isset($_POST['add_book'])) {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $author = mysqli_real_escape_string($conn, $_POST['author']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);

    $sql = "INSERT INTO books(title, author, price)
            VALUES('$title', '$author', '$price')";

    if (mysqli_query($conn, $sql)) {
        header("Location: ../books.php");
        exit();
    } else {
        $message = "Failed to add book!";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Add New Book</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f4f6f9;
        }

        .navbar {
            background: #2563eb;
            padding: 15px;
            text-align: center;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            margin: 0 20px;
            font-size: 18px;
            font-weight: bold;
        }

        .navbar a:hover {
            color: #ddd;
        }

        .form-container {
            width: 500px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .form-container h2 {
            text-align: center;
            color: #2563eb;
            margin-bottom: 25px;
        }

        .form-container label {
            display: block;
            margin-top: 15px;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-container input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
        }

        .form-container button {
            width: 100%;
            padding: 12px;
            margin-top: 20px;
            background: #2563eb;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
        }

        .form-container button:hover {
            background: #1d4ed8;
        }

        .back-btn {
            display: inline-block;
            margin-top: 15px;
            background: #6b7280;
            color: white;
            padding: 10px 15px;
            border-radius: 6px;
            text-decoration: none;
        }

        .message {
            color: red;
            text-align: center;
            margin-bottom: 10px;
        }
    </style>

</head>

<body>

    <div class="navbar">
        <a href="../dashboard.php">Dashboard</a>
        <a href="../books.php">Books</a>
        <a href="../logout.php">Logout</a>
    </div>

    <div class="form-container">

        <h2>📚 Add New Book</h2>

        <?php
        if ($message != "") {
            echo "<p class='message'>$message</p>";
        }
        ?>

        <form method="POST">

            <label>Book Title</label>
            <input type="text" name="title" placeholder="Enter Book Title" required>

            <label>Author Name</label>
            <input type="text" name="author" placeholder="Enter Author Name" required>

            <label>Price</label>
            <input type="number" step="0.01" name="price" placeholder="Enter Price" required>

            <button type="submit" name="add_book">
                Add Book
            </button>

        </form>

        <a href="../books.php" class="back-btn">
            ← Back to Books
        </a>

    </div>

</body>

</html>