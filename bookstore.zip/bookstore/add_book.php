<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../login.php");
    exit();
}

include("../config/db.php");

$message = "";

if (isset($_POST['add_book'])) {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $author = mysqli_real_escape_string($conn, $_POST['author']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);

    $sql = "INSERT INTO books(title, author, price)
            VALUES('$title', '$author', '$price')";

    if (mysqli_query($conn, $sql)) {
        header("Location: ../books.php");
        exit();
    } else {
        $message = "Error adding book!";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Add New Book</title>

    <link rel="stylesheet" href="../css/style.css">

    <style>
        .form-container {
            width: 500px;
            margin: 50px auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #2563eb;
        }

        .back-btn {
            display: inline-block;
            margin-top: 15px;
            text-decoration: none;
            background: #6c757d;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
        }

        .success {
            color: green;
            text-align: center;
            margin-bottom: 10px;
        }

        .error {
            color: red;
            text-align: center;
            margin-bottom: 10px;
        }
    </style>

</head>

<body>

    <div class="navbar">
        <a href="../dashboard.php">Dashboard</a>
        <a href="../books.php">Books</a>
        <a href="../logout.php">Logout</a>
    </div>

    <div class="form-container">

        <h2>📚 Add New Book</h2>

            <?php if ($message != "") { ?>
            <p class="error">
                <?php echo $message; ?>
                    </p>
        <?php } ?>

        <form method="POST">

            <label>Book Title</label>
            <input type="text" name="title" placeholder="Enter Book Title" required>

            <label>Author Name</label>
            <input type="text" name="author" placeholder="Enter Author Name" required>

            <label>Price</label>
            <input type="number" step="0.01" name="price" placeholder="Enter Price" required>

            <button type="submit" name="add_book">
                Add Book
            </button>

        </form>

        <a href="../books.php" class="back-btn">
            ← Back to Books
        </a>

    </div>

</body>

</html>