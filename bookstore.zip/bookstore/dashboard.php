<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

include("config/db.php");

$userCount = mysqli_num_rows(
    mysqli_query($conn, "SELECT * FROM users")
);

$bookCount = mysqli_num_rows(
    mysqli_query($conn, "SELECT * FROM books")
);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <div class="navbar">
        <a href="dashboard.php">Dashboard</a>
        <a href="books.php">Books</a>
        <a href="logout.php">Logout</a>
    </div>

    <div class="dashboard">

        <div class="card">
            <h2>Total Users</h2>
            <p>
                <?php echo $userCount; ?>
            </p>
        </div>

        <div class="card">
            <h2>Total Books</h2>
            <p>
                <?php echo $bookCount; ?>
            </p>
        </div>

    </div>

</body>

</html>