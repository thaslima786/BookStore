<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

include("config/db.php");

$search = "";

if (isset($_GET['search'])) {
    $search = mysqli_real_escape_string($conn, $_GET['search']);
}

$query = "SELECT * FROM books
          WHERE title LIKE '%$search%'
          OR author LIKE '%$search%'
          ORDER BY id DESC";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Books Management</title>
    <link rel="stylesheet" href="css/style.css">

    <style>
        .edit-btn {
            background: #f59e0b;
            color: white;
            padding: 8px 12px;
            text-decoration: none;
            border-radius: 5px;
            margin-right: 5px;
        }

        .delete-btn {
            background: #dc2626;
            color: white;
            padding: 8px 12px;
            text-decoration: none;
            border-radius: 5px;
        }

        .edit-btn:hover {
            background: #d97706;
        }

        .delete-btn:hover {
            background: #b91c1c;
        }
    </style>
</head>

<body>

    <div class="navbar">
        <a href="dashboard.php">Dashboard</a>
        <a href="books.php">Books</a>
        <a href="logout.php">Logout</a>
    </div>

    <h1 class="page-title">📚 Books Management</h1>

    <div class="table-container">

        <form method="GET" class="search-box">

            <input type="text" name="search" placeholder="Search by Title or Author" value="<?php echo $search; ?>">

            <button type="submit">
                Search
            </button>

        </form>

        <br>

        <a href="admin/add_book.php" class="add-btn">
            + Add New Book
        </a>

        <br><br>

        <table border="1" width="100%" cellpadding="10">

            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Author</th>
                <th>Price</th>
                <th>Actions</th>
            </tr>

            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    ?>

                    <tr>

                        <td>
                            <?php echo $row['id']; ?>
                        </td>

                        <td>
                            <?php echo $row['title']; ?>
                        </td>

                        <td>
                            <?php echo $row['author']; ?>
                        </td>

                        <td>₹
                            <?php echo $row['price']; ?>
                        </td>

                        <td>

                            <a class="edit-btn" href="admin/edit_book.php?id=<?php echo $row['id']; ?>">
                                Edit
                            </a>

                            <a class="delete-btn" href="admin/delete_book.php?id=<?php echo $row['id']; ?>"
                                onclick="return confirm('Are you sure you want to delete this book?');">
                                Delete
                            </a>

                        </td>

                    </tr>

                    <?php
                }
            } else {
                ?>

                <tr>
                    <td colspan="5">No Books Found</td>
                </tr>

                <?php
            }
            ?>

        </table>

    </div>

</body>

</html>